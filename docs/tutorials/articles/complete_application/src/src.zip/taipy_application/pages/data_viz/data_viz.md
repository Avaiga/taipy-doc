# Getting started with Taipy

Select week: *<|{n_week}|>*

<|{n_week}|slider|min=1|max=52|on_change=slider_moved|>

<|{dataset_week}|chart|type=bar|x=Date|y=Value|>