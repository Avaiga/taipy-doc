from taipy import Gui

if __name__ == "__main__":
    Gui(page="# Getting started with *Taipy*").run(debug=True)
