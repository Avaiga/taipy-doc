from taipy import Gui

Gui(page="# Getting started with *Taipy*").run(debug=True)
