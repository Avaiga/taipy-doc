from .data_viz import data_viz
from .scenario import scenario_page
from .performance import performance
from .root import root_page
